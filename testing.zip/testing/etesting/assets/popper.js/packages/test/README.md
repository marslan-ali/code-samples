# Popper.js scripts

This package is a list of scripts used by Popper.js and Tooltip.js to
test the packages.

It's not intended to be used outside of Popper.js repository.
